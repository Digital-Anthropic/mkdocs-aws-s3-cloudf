exports.handler = async (event) => {
    const request = event.Records[0].cf.request;
    const uri = request.uri;
    
    request.uri = uri.endsWith("/") ? uri + "index.html" : uri;
    
    return request;
};